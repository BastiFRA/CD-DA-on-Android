package com.example.cddaplayer

import android.app.Activity
import android.hardware.usb.*
import android.media.*
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var usbManager: UsbManager
    private var connection: UsbDeviceConnection? = null
    private var bot: Bot? = null
    private var player: CddaPlayer? = null

    private lateinit var status: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnStop: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usbManager = getSystemService(UsbManager::class.java)
        status = findViewById(R.id.status)
        btnPlay = findViewById(R.id.btnPlay)
        btnStop = findViewById(R.id.btnStop)

        btnPlay.setOnClickListener {
            startPlayback()
        }
        btnStop.setOnClickListener {
            player?.stop()
        }

        handleIntentDevice(intent.getParcelableExtra(UsbManager.EXTRA_DEVICE))
    }

    override fun onNewIntent(intent: android.content.Intent?) {
        super.onNewIntent(intent)
        handleIntentDevice(intent?.getParcelableExtra(UsbManager.EXTRA_DEVICE))
    }

    private fun handleIntentDevice(device: UsbDevice?) {
        device ?: return
        if (!usbManager.hasPermission(device)) {
            val pi = android.app.PendingIntent.getActivity(this, 0, intent, 0)
            usbManager.requestPermission(device, pi)
            status.text = "Requesting USB permission…"
            return
        }
        openDevice(device)
    }

    private fun openDevice(device: UsbDevice) {
        val msIf = (0 until device.interfaceCount)
            .map { device.getInterface(it) }
            .firstOrNull { it.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE }
            ?: run { status.text = "No Mass Storage interface"; return }

        val conn = usbManager.openDevice(device)
        if (conn == null) { status.text = "Open device failed"; return }
        if (!conn.claimInterface(msIf, true)) { status.text = "Claim interface failed"; return }

        val epIn = (0 until msIf.endpointCount).map { msIf.getEndpoint(it) }
            .first { it.type == UsbConstants.USB_ENDPOINT_XFER_BULK && it.direction == UsbConstants.USB_DIR_IN }
        val epOut = (0 until msIf.endpointCount).map { msIf.getEndpoint(it) }
            .first { it.type == UsbConstants.USB_ENDPOINT_XFER_BULK && it.direction == UsbConstants.USB_DIR_OUT }

        connection = conn
        bot = Bot(conn, epIn, epOut)
        status.text = "Drive connected. Try Play."
    }

    private fun startPlayback() {
        val b = bot ?: run { status.text = "No drive"; return }
        player?.stop()
        player = CddaPlayer(b, status)
        player?.playTrack1()
    }
}
