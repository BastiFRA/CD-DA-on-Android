package com.example.cddaplayer

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.media.*
import android.widget.TextView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

class Bot(private val conn: UsbDeviceConnection, private val epIn: UsbEndpoint, private val epOut: UsbEndpoint) {
    private var tag = 1

    private fun bulkOut(buf: ByteArray, timeout: Int) {
        val n = conn.bulkTransfer(epOut, buf, buf.size, timeout)
        if (n < 0) throw RuntimeException("bulk out failed")
    }
    private fun bulkIn(len: Int, timeout: Int): ByteArray {
        val buf = ByteArray(len)
        val n = conn.bulkTransfer(epIn, buf, len, timeout)
        if (n < 0) throw RuntimeException("bulk in failed")
        return if (n == len) buf else buf.copyOf(n)
    }

    fun scsi(cdb: ByteArray, dataInLen: Int = 0, dataOut: ByteArray? = null): ByteArray {
        val cbw = ByteArray(31)
        // 'USBC' signature
        cbw[0]=0x55; cbw[1]=0x53; cbw[2]=0x42; cbw[3]=0x43
        ByteBuffer.wrap(cbw,4,4).order(ByteOrder.LITTLE_ENDIAN).putInt(tag++)
        ByteBuffer.wrap(cbw,8,4).order(ByteOrder.LITTLE_ENDIAN).putInt(maxOf(dataInLen, dataOut?.size ?: 0))
        cbw[12] = if (dataInLen>0) 0x80.toByte() else 0x00.toByte()
        cbw[13] = 0
        cbw[14] = cdb.size.toByte()
        System.arraycopy(cdb, 0, cbw, 15, cdb.size)

        bulkOut(cbw, 1000)
        if (dataOut != null) bulkOut(dataOut, 5000)
        val dataIn = if (dataInLen>0) bulkIn(dataInLen, 8000) else ByteArray(0)
        val csw = bulkIn(13, 2000)
        if (csw.size != 13 || csw[12].toInt() != 0) throw RuntimeException("SCSI status not GOOD")
        return dataIn
    }

    fun inquiry(): ByteArray = scsi(byteArrayOf(0x12,0,0,0,36,0), dataInLen=36)
    fun testUnitReady() = scsi(byteArrayOf(0x00,0,0,0,0,0))
    fun startStop(start: Boolean) = scsi(byteArrayOf(0x1B,0,0,0, if (start) 0x01 else 0x00, 0))
    fun readToc(): ByteArray = scsi(byteArrayOf(0x43, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x00), dataInLen=0x18)

    fun readCdDa(lba: Int, sectors: Int): ByteArray {
        val cdb = ByteArray(12)
        cdb[0] = 0xBE.toByte()
        cdb[1] = 0x00
        cdb[2] = ((lba ushr 24) and 0xFF).toByte()
        cdb[3] = ((lba ushr 16) and 0xFF).toByte()
        cdb[4] = ((lba ushr  8) and 0xFF).toByte()
        cdb[5] = ( lba         and 0xFF).toByte()
        cdb[6] = ((sectors ushr 16) and 0xFF).toByte()
        cdb[7] = ((sectors ushr  8) and 0xFF).toByte()
        cdb[8] = ( sectors         and 0xFF).toByte()
        cdb[9] = 0x10 // 2352 user data only
        cdb[10] = 0x00
        cdb[11] = 0x00
        val bytes = sectors * 2352
        return scsi(cdb, dataInLen = bytes)
    }
}

class CddaPlayer(private val bot: Bot, private val status: TextView) {
    @Volatile private var playing = false
    private var track: AudioTrack? = null

    fun playTrack1() {
        playing = true
        status.text = "Starting…"
        thread {
            try {
                bot.startStop(true)
                // Very naive: assume track 1 starts at LBA 00:02:00 (150) and play ~2 minutes
                val startLba = 150
                val endLba = startLba + (2 * 60 * 75) // 2 minutes demo
                val at = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(44100)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build())
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(44100 * 4)
                    .build()
                track = at
                at.play()
                var cur = startLba
                val swap = { buf: ByteArray ->
                    var i = 0
                    while (i < buf.size) {
                        val b0 = buf[i]; buf[i] = buf[i+1]; buf[i+1] = b0
                        i += 2
                    }
                }
                while (playing && cur < endLba) {
                    val nsec = 8
                    val raw = bot.readCdDa(cur, nsec)
                    swap(raw)
                    at.write(raw, 0, raw.size)
                    cur += nsec
                }
                status.post { status.text = "Done / Stopped." }
            } catch (e: Exception) {
                status.post { status.text = "Error: ${e.message}" }
            }
        }
    }

    fun stop() {
        playing = false
        track?.stop()
        track?.release()
        track = null
        status.text = "Stopped."
    }
}
